#!/usr/bin/env python3
"""
Тест Bitquery API для Four.Meme
"""
import asyncio
import aiohttp
import sys
from datetime import datetime, timezone, timedelta

sys.path.append('.')

from main import BITQUERY_API_KEY, logger

async def test_bitquery_api():
    """Тестируем Bitquery API"""
    print("🧪 Тестируем Bitquery API...")
    
    if not BITQUERY_API_KEY:
        print("❌ Bitquery API key not configured")
        return
    
    # Простой запрос для проверки API
    query = """
    query {
      EVM(dataset: combined, network: bsc) {
        DEXTradeByTokens(
          orderBy: {descendingByField: "Block_Time"}
          limit: {count: 10}
          where: {
            Trade: {
              Dex: {ProtocolName: {is: "fourmeme_v1"}}
            }
            Block: {
              Time: {
                since: "2025-10-14T00:00:00Z"
              }
            }
          }
        ) {
          Trade {
            Currency {
              Name
              Symbol
              SmartContract
            }
            Block {
              Time
            }
          }
          volumeUsd: sum(of: Trade_Side_AmountInUSD)
          count: count
        }
      }
    }
    """

    headers = {
        "Authorization": f"Bearer {BITQUERY_API_KEY}",
        "Content-Type": "application/json"
    }

    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(
                "https://graphql.bitquery.io",
                json={"query": query},
                headers=headers,
                timeout=30
            ) as response:
                print(f"📡 Статус ответа: {response.status}")
                
                if response.status != 200:
                    text = await response.text()
                    print(f"❌ Ошибка HTTP: {text}")
                    return
                
                data = await response.json()
                
                if "errors" in data:
                    print(f"❌ GraphQL ошибки: {data['errors']}")
                    return
                
                trades = data.get("data", {}).get("EVM", {}).get("DEXTradeByTokens", [])
                print(f"✅ Получено токенов: {len(trades)}")
                
                if trades:
                    print("\n📊 Первые 3 токена:")
                    for i, trade in enumerate(trades[:3], 1):
                        currency = trade["Trade"]["Currency"]
                        volume = trade.get("volumeUsd", 0)
                        count = trade.get("count", 0)
                        print(f"{i}. {currency['Symbol']} ({currency['Name']})")
                        print(f"   Адрес: {currency['SmartContract']}")
                        print(f"   Объем: ${volume:,.0f}")
                        print(f"   Сделок: {count}")
                        print()
                else:
                    print("📭 Нет токенов в результатах")
                    
        except Exception as e:
            print(f"❌ Ошибка: {e}")

if __name__ == "__main__":
    asyncio.run(test_bitquery_api())
