#!/bin/bash

# Тест конкретных токенов на сервере

SERVER_USER="ubuntu"
SERVER_HOST="158.160.78.224"
SERVER_PORT="22"
PROJECT_DIR="~/pancake-bot"
SSH_KEY="$HOME/.ssh/id_rsa"

TOKENS=(
    "0xdd2422a7f797cdfb060193bd20f514d8759c7777"
    "0x1a5acdd9467854a85b9c45fb20010ebb89114444"
    "0xae7b3bea74d81d3e4e75eb359a56bf3340ac7777"
)

SSH_CMD="ssh"
if [ ! -z "$SSH_KEY" ] && [ -f "$SSH_KEY" ]; then
    SSH_CMD="$SSH_CMD -i $SSH_KEY"
fi
SSH_CMD="$SSH_CMD -p $SERVER_PORT $SERVER_USER@$SERVER_HOST"

echo "🔍 Проверка токенов на сервере..."
echo ""

for token in "${TOKENS[@]}"; do
    echo "=========================================="
    echo "Токен: $token"
    echo "=========================================="
    
    $SSH_CMD "cd $PROJECT_DIR && grep '$token' new_tokens_bot.log | tail -10" || echo "Токен не найден в логах"
    echo ""
done

echo "=========================================="
echo "Проверка последних GMGN запросов:"
echo "=========================================="
$SSH_CMD "cd $PROJECT_DIR && tail -100 new_tokens_bot.log | grep -E 'GMGN data fetched|total_fees|Skipping.*total fees' | tail -10"
