#!/usr/bin/env python3
"""
Тест для проверки обнаружения CGN токена
"""

import asyncio
import aiohttp
import logging
from main_base import fetch_dexscreener_usdc_pairs, fetch_dexscreener_token_by_address, parse_dexscreener_pair

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

async def test_cgn_detection():
    """Тестирует обнаружение CGN токена"""
    logger.info("🧪 Testing CGN token detection...")
    
    # Адрес CGN токена
    CGN_ADDRESS = "0x2e6C4BD1C947e195645d2B920b827498cfAa6766"
    
    async with aiohttp.ClientSession() as session:
        # Получаем USDC пары
        usdc_pairs = await fetch_dexscreener_usdc_pairs(session)
        
        logger.info(f"📊 Found {len(usdc_pairs)} USDC pairs")
        
        if not usdc_pairs:
            logger.warning("❌ No USDC pairs found!")
            return False
        
        # Ищем CGN токен
        cgn_found = False
        for pair in usdc_pairs:
            parsed = parse_dexscreener_pair(pair, is_usdc_pair=True)
            if parsed and parsed['token_address'].lower() == CGN_ADDRESS.lower():
                cgn_found = True
                logger.info(f"🎯 CGN token found!")
                logger.info(f"📊 Symbol: {parsed['token_symbol']}")
                logger.info(f"📊 Name: {parsed['token_name']}")
                logger.info(f"📊 Volume 5m: ${parsed['volume_5m']:,.0f}")
                logger.info(f"📊 Age: {parsed['age_hours']:.2f} hours")
                logger.info(f"📊 Source: {parsed['source']}")
                logger.info(f"📊 Pair: {parsed['pair_name']}")
                break
        
        if not cgn_found:
            logger.warning("❌ CGN token not found in USDC pairs")
            # Показываем первые несколько токенов для отладки
            logger.info("🔍 First few tokens found:")
            for i, pair in enumerate(usdc_pairs[:5]):
                parsed = parse_dexscreener_pair(pair, is_usdc_pair=True)
                if parsed:
                    logger.info(f"  {i+1}. {parsed['token_symbol']} ({parsed['token_address'][:10]}...)")
            
            # Пробуем найти CGN токен напрямую по адресу
            logger.info("🔍 Trying direct token search...")
            cgn_pairs = await fetch_dexscreener_token_by_address(session, CGN_ADDRESS)
            
            if cgn_pairs:
                logger.info(f"🎯 CGN token found via direct search! Found {len(cgn_pairs)} pairs")
                for pair in cgn_pairs:
                    parsed = parse_dexscreener_pair(pair, is_usdc_pair=False)
                    if parsed:
                        logger.info(f"📊 Symbol: {parsed['token_symbol']}")
                        logger.info(f"📊 Name: {parsed['token_name']}")
                        logger.info(f"📊 Volume 5m: ${parsed['volume_5m']:,.0f}")
                        logger.info(f"📊 Age: {parsed['age_hours']:.2f} hours")
                        logger.info(f"📊 Source: {parsed['source']}")
                        logger.info(f"📊 Pair: {parsed['pair_name']}")
                        cgn_found = True
                        break
            else:
                logger.warning("❌ CGN token not found via direct search either")
        else:
            logger.info("✅ CGN token detection test passed!")
        
        return cgn_found

if __name__ == "__main__":
    asyncio.run(test_cgn_detection())