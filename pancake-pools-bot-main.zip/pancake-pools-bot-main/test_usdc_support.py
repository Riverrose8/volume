#!/usr/bin/env python3
"""
Тест поддержки USDC пар в Base боте
"""

import asyncio
import aiohttp
import logging
from main_base import fetch_dexscreener_usdc_pairs, parse_dexscreener_pair

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

async def test_usdc_support():
    """Тестирует поддержку USDC пар"""
    logger.info("🧪 Testing USDC pairs support...")
    
    async with aiohttp.ClientSession() as session:
        # Получаем USDC пары
        usdc_pairs = await fetch_dexscreener_usdc_pairs(session)
        
        logger.info(f"📊 Found {len(usdc_pairs)} USDC pairs")
        
        if not usdc_pairs:
            logger.warning("❌ No USDC pairs found!")
            return
        
        # Парсим первые 5 пар
        parsed_count = 0
        for i, pair in enumerate(usdc_pairs[:5]):
            parsed = parse_dexscreener_pair(pair, is_usdc_pair=True)
            if parsed:
                parsed_count += 1
                logger.info(f"✅ Pair {i+1}: {parsed['token_symbol']} - Vol: ${parsed['volume_5m']:,.0f}, Source: {parsed['source']}")
            else:
                logger.warning(f"❌ Failed to parse pair {i+1}")
        
        logger.info(f"📈 Successfully parsed {parsed_count}/5 pairs")
        
        # Проверяем, что источник правильно установлен
        if parsed_count > 0:
            logger.info("🎯 USDC support is working correctly!")
        else:
            logger.error("❌ USDC support failed!")

if __name__ == "__main__":
    asyncio.run(test_usdc_support())
