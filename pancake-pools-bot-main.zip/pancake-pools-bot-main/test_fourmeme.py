#!/usr/bin/env python3
"""
Тест интеграции Four.Meme API
"""
import asyncio
import aiohttp
import os
import sys

# Добавляем текущую директорию в путь
sys.path.append('.')

from main import fetch_fourmeme_tokens, parse_fourmeme_token

async def test_fourmeme():
    """Тестируем Four.Meme API"""
    print("🔍 Testing Four.Meme integration...")
    
    # Проверяем API ключ
    bitquery_key = os.getenv("BITQUERY_API_KEY")
    if not bitquery_key:
        print("❌ BITQUERY_API_KEY not set in environment")
        print("   Set it with: export BITQUERY_API_KEY=your_key_here")
        return
    
    print(f"✅ Bitquery API key found: {bitquery_key[:10]}...")
    
    async with aiohttp.ClientSession() as session:
        try:
            tokens = await fetch_fourmeme_tokens(session)
            print(f"✅ Fetched {len(tokens)} tokens from Four.Meme")
            
            if tokens:
                print("\n📊 Sample tokens:")
                for i, token in enumerate(tokens[:5]):  # Показываем первые 5
                    parsed = parse_fourmeme_token(token)
                    if parsed:
                        print(f"{i+1}. {parsed['token_symbol']} - Vol: ${parsed['volume_5m']:,.0f}, Age: {parsed['age_hours']:.2f}h")
            else:
                print("ℹ️ No tokens found (this is normal if no recent activity)")
                
        except Exception as e:
            print(f"❌ Error testing Four.Meme: {e}")

if __name__ == "__main__":
    asyncio.run(test_fourmeme())
