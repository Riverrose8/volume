#!/usr/bin/env python3
"""
Тест Bitquery API - проверяем поддерживаемые сети
"""

import asyncio
import aiohttp
import json
from dotenv import load_dotenv
import os

# Загружаем переменные окружения
load_dotenv('.env_base')

BITQUERY_API_KEY = os.getenv("BITQUERY_API_KEY")

async def test_network_values():
    """Тестируем различные значения для сети"""
    
    if not BITQUERY_API_KEY:
        print("❌ BITQUERY_API_KEY не найден в .env_base")
        return False
    
    print(f"🔑 Используем API ключ: {BITQUERY_API_KEY[:20]}...")
    
    # Возможные значения для Base сети
    network_values = [
        "base",
        "base-mainnet", 
        "base_mainnet",
        "base-mainnet",
        "basechain",
        "base_chain",
        "ethereum-base",
        "base-ethereum"
    ]
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {BITQUERY_API_KEY}"
    }
    
    # Простой запрос для тестирования
    base_query = """
    query {
      ethereum(network: {NETWORK}) {
        transactions(options: {limit: 1}) {
          hash
        }
      }
    }
    """
    
    for network in network_values:
        print(f"\n🧪 Тестируем сеть: {network}")
        
        query = base_query.replace("{NETWORK}", network)
        payload = {"query": query}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "https://graphql.bitquery.io",
                    headers=headers,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        if "data" in data and data["data"]:
                            print(f"✅ {network} - РАБОТАЕТ!")
                            ethereum_data = data["data"].get("ethereum", {})
                            if ethereum_data and "transactions" in ethereum_data:
                                transactions = ethereum_data["transactions"]
                                print(f"   Найдено {len(transactions)} транзакций")
                        elif "errors" in data:
                            errors = data["errors"]
                            if any("invalid value" in error.get("message", "") for error in errors):
                                print(f"❌ {network} - неверное значение")
                            else:
                                print(f"⚠️ {network} - ошибка: {errors[0]['message']}")
                        else:
                            print(f"❌ {network} - неизвестная ошибка")
                    else:
                        print(f"❌ {network} - HTTP {response.status}")
                        
        except Exception as e:
            print(f"❌ {network} - ошибка: {e}")
    
    return True

async def test_ethereum_mainnet():
    """Тестируем Ethereum mainnet для сравнения"""
    
    print("\n" + "="*60)
    print("🧪 ТЕСТ: Ethereum mainnet (для сравнения)")
    print("="*60)
    
    query = """
    query {
      ethereum {
        transactions(options: {limit: 1}) {
          hash
          block {
            timestamp {
              time
            }
          }
        }
      }
    }
    """
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {BITQUERY_API_KEY}"
    }
    
    payload = {"query": query}
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://graphql.bitquery.io",
                headers=headers,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=10)
            ) as response:
                
                if response.status == 200:
                    data = await response.json()
                    
                    if "data" in data and data["data"]:
                        print("✅ Ethereum mainnet работает!")
                        ethereum_data = data["data"].get("ethereum", {})
                        if ethereum_data and "transactions" in ethereum_data:
                            transactions = ethereum_data["transactions"]
                            print(f"📈 Найдено {len(transactions)} транзакций")
                            if transactions:
                                tx = transactions[0]
                                print(f"   Пример: {tx['hash'][:20]}...")
                    else:
                        print("❌ Ошибка в ответе API:")
                        if "errors" in data:
                            for error in data["errors"]:
                                print(f"  - {error['message']}")
                else:
                    print(f"❌ HTTP ошибка: {response.status}")
                    
    except Exception as e:
        print(f"❌ Ошибка: {e}")

async def main():
    print("🚀 Тестирование поддерживаемых сетей в Bitquery API")
    print("="*60)
    
    # Тестируем Ethereum mainnet
    await test_ethereum_mainnet()
    
    # Тестируем различные значения для Base
    await test_network_values()
    
    print("\n" + "="*60)
    print("✅ Тестирование завершено!")
    print("💡 Если Base сеть не поддерживается, можно использовать Ethereum mainnet")

if __name__ == "__main__":
    asyncio.run(main())
