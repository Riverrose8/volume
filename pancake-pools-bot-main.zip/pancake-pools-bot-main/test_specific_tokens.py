#!/usr/bin/env python3
"""
Тест получения GMGN данных для конкретных токенов
"""

import asyncio
import aiohttp
import os
import json
import sys
from dotenv import load_dotenv

# Добавляем текущую директорию в путь
sys.path.append('.')

load_dotenv()

from main import fetch_gmgn_token_data, fetch_gmgn_via_apify

async def test_token(token_address: str):
    """Тестирует получение GMGN данных для токена"""
    print(f"\n{'='*60}")
    print(f"🔍 Тестирование токена: {token_address}")
    print(f"{'='*60}")
    
    async with aiohttp.ClientSession() as session:
        # Тест 1: Через Apify (если доступен)
        apify_token = os.getenv("APIFY_API_TOKEN", "")
        if apify_token:
            print(f"\n1️⃣ Тест через Apify API:")
            try:
                apify_data = await fetch_gmgn_via_apify(session, token_address, apify_token)
                if apify_data:
                    print(f"   ✅ Данные получены через Apify:")
                    print(f"      - total_fees_bnb: {apify_data.get('total_fees_bnb')}")
                    print(f"      - top_10_holder_rate: {apify_data.get('top_10_holder_rate')}")
                    print(f"      - creator_open_count: {apify_data.get('creator_open_count')}")
                    print(f"      - buy_sell_ratio: {apify_data.get('buy_sell_ratio')}")
                    print(f"      - creator_address: {apify_data.get('creator_address')}")
                else:
                    print(f"   ❌ Apify вернул пустые данные")
            except Exception as e:
                print(f"   ❌ Ошибка Apify: {e}")
                import traceback
                traceback.print_exc()
        else:
            print(f"\n1️⃣ Apify API токен не установлен, пропускаем")
        
        # Тест 2: Через общую функцию (с fallback на HTML)
        print(f"\n2️⃣ Тест через fetch_gmgn_token_data (с fallback):")
        try:
            gmgn_data = await fetch_gmgn_token_data(session, token_address)
            if gmgn_data:
                print(f"   ✅ Данные получены:")
                print(f"      - total_fees_bnb: {gmgn_data.get('total_fees_bnb')}")
                print(f"      - bundler_percentage: {gmgn_data.get('bundler_percentage')}")
                print(f"      - top_10_holder_rate: {gmgn_data.get('top_10_holder_rate')}")
                print(f"      - creator_open_count: {gmgn_data.get('creator_open_count')}")
                print(f"      - buy_sell_ratio: {gmgn_data.get('buy_sell_ratio')}")
                print(f"      - creator_address: {gmgn_data.get('creator_address')}")
            else:
                print(f"   ❌ Данные не получены")
        except Exception as e:
            print(f"   ❌ Ошибка: {e}")
            import traceback
            traceback.print_exc()
        
        # Тест 3: Прямой запрос к GMGN странице
        print(f"\n3️⃣ Проверка GMGN страницы:")
        try:
            url = f"https://gmgn.ai/bsc/token/{token_address}"
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            async with session.get(url, headers=headers, timeout=15) as r:
                if r.status == 200:
                    print(f"   ✅ Страница доступна (HTTP {r.status})")
                    html = await r.text()
                    # Проверяем наличие ключевых слов
                    if "Total Fees" in html or "total fees" in html.lower():
                        print(f"   ✅ Найдено упоминание 'Total Fees' на странице")
                    else:
                        print(f"   ⚠️  'Total Fees' не найдено на странице")
                else:
                    print(f"   ❌ Ошибка доступа: HTTP {r.status}")
        except Exception as e:
            print(f"   ❌ Ошибка запроса: {e}")

async def main():
    """Тестирует все указанные токены"""
    tokens = [
        "0xdd2422a7f797cdfb060193bd20f514d8759c7777",
        "0x1a5acdd9467854a85b9c45fb20010ebb89114444",
        "0xae7b3bea74d81d3e4e75eb359a56bf3340ac7777"
    ]
    
    print("="*60)
    print("ТЕСТИРОВАНИЕ ПОЛУЧЕНИЯ GMGN ДАННЫХ")
    print("="*60)
    
    for token in tokens:
        await test_token(token)
        await asyncio.sleep(2)  # Задержка между запросами
    
    print(f"\n{'='*60}")
    print("✅ ТЕСТИРОВАНИЕ ЗАВЕРШЕНО")
    print(f"{'='*60}")

if __name__ == "__main__":
    asyncio.run(main())
