#!/usr/bin/env python3
"""
Тест для проверки обнаружения конкретного Virtuals токена
"""

import asyncio
import aiohttp
import logging
from main_base import fetch_dexscreener_token_by_address, parse_dexscreener_pair

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

async def test_virtuals_token_detection():
    """Тестирует обнаружение конкретного Virtuals токена"""
    logger.info("🧪 Testing Virtuals token detection...")
    
    # Адрес токена, который ты упомянул
    VIRTUALS_TOKEN_ADDRESS = "0x55fF51DA774b8ce0ed1ABAeD1CB76236bc6b2f16"
    
    async with aiohttp.ClientSession() as session:
        # Ищем токен напрямую по адресу
        logger.info("🔍 Trying direct token search...")
        token_pairs = await fetch_dexscreener_token_by_address(session, VIRTUALS_TOKEN_ADDRESS)
        
        if token_pairs:
            logger.info(f"🎯 Token found via direct search! Found {len(token_pairs)} pairs")
            for pair in token_pairs:
                parsed = parse_dexscreener_pair(pair, is_usdc_pair=False, is_virtuals_pair=False)
                if parsed:
                    logger.info(f"📊 Symbol: {parsed['token_symbol']}")
                    logger.info(f"📊 Name: {parsed['token_name']}")
                    logger.info(f"📊 Volume 5m: ${parsed['volume_5m']:,.0f}")
                    logger.info(f"📊 Age: {parsed['age_hours']:.2f} hours")
                    logger.info(f"📊 Source: {parsed['source']}")
                    logger.info(f"📊 Pair: {parsed['pair_name']}")
                    
                    # Проверяем, торгуется ли с Virtuals
                    if "VIRTUALS" in parsed['pair_name'].upper():
                        logger.info("🎯 This is a Virtuals pair!")
                        # Обновляем источник
                        parsed['source'] = 'dexscreener_virtuals'
                        logger.info(f"📊 Updated Source: {parsed['source']}")
                        logger.info("🚀 This would show 'Launchpad: Virtuals' in alerts")
                    break
        else:
            logger.warning("❌ Token not found via direct search")
            logger.info("💡 This might mean:")
            logger.info("   - Token is no longer actively trading")
            logger.info("   - Token address might be incorrect")
            logger.info("   - DexScreener doesn't have data for this token")
        
        return len(token_pairs) > 0

if __name__ == "__main__":
    asyncio.run(test_virtuals_token_detection())
