#!/usr/bin/env python3
"""
Тест поддержки Virtuals пар в Base боте
"""

import asyncio
import aiohttp
import logging
from main_base import fetch_dexscreener_virtuals_pairs, parse_dexscreener_pair

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

async def test_virtuals_support():
    """Тестирует поддержку Virtuals пар"""
    logger.info("🧪 Testing Virtuals pairs support...")
    
    async with aiohttp.ClientSession() as session:
        # Получаем Virtuals пары
        virtuals_pairs = await fetch_dexscreener_virtuals_pairs(session)
        
        logger.info(f"📊 Found {len(virtuals_pairs)} Virtuals pairs")
        
        if not virtuals_pairs:
            logger.warning("❌ No Virtuals pairs found!")
            return False
        
        # Парсим первые 5 пар
        parsed_count = 0
        for i, pair in enumerate(virtuals_pairs[:5]):
            parsed = parse_dexscreener_pair(pair, is_usdc_pair=False, is_virtuals_pair=True)
            if parsed:
                parsed_count += 1
                logger.info(f"✅ Pair {i+1}: {parsed['token_symbol']} - Vol: ${parsed['volume_5m']:,.0f}, Source: {parsed['source']}")
            else:
                logger.warning(f"❌ Failed to parse pair {i+1}")
        
        logger.info(f"📈 Successfully parsed {parsed_count}/5 pairs")
        
        # Проверяем, что источник правильно установлен
        if parsed_count > 0:
            logger.info("🎯 Virtuals support is working correctly!")
            logger.info("🚀 Virtuals pairs will show 'Launchpad: Virtuals' in alerts")
        else:
            logger.error("❌ Virtuals support failed!")
        
        return parsed_count > 0

if __name__ == "__main__":
    asyncio.run(test_virtuals_support())
