#!/usr/bin/env python3
"""
Быстрый тест API Polymarket Builders
Проверяет доступность endpoints и выводит пример данных
"""

import asyncio
import aiohttp
import json


async def test_api():
    """Тестирует API endpoints"""
    
    base_url = "https://data-api.polymarket.com/v1"
    
    async with aiohttp.ClientSession() as session:
        print("🧪 Тестирование Polymarket Builders API")
        print("=" * 60)
        
        # Тест 1: Builder Leaderboard
        print("\n1️⃣ Тест: Builder Leaderboard (WEEK, top 5)")
        try:
            url = f"{base_url}/builders/leaderboard"
            params = {"timePeriod": "WEEK", "limit": 5, "offset": 0}
            
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    print(f"   ✅ Успешно! Получено builders: {len(data)}")
                    if data:
                        print(f"\n   Топ-3 builders:")
                        for i, builder in enumerate(data[:3], 1):
                            print(f"   {i}. {builder.get('builder', 'N/A')}: "
                                  f"${builder.get('volume', 0):,} | "
                                  f"Users: {builder.get('activeUsers', 0)}")
                else:
                    print(f"   ❌ Ошибка: HTTP {resp.status}")
        except Exception as e:
            print(f"   ❌ Исключение: {e}")
        
        # Тест 2: Builder Volume Time-Series
        print("\n2️⃣ Тест: Builder Volume Time-Series (WEEK)")
        try:
            url = f"{base_url}/builders/volume"
            params = {"timePeriod": "WEEK"}
            
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    print(f"   ✅ Успешно! Получено записей: {len(data)}")
                    if data:
                        # Группируем по builder'ам
                        builders = {}
                        for entry in data:
                            builder = entry.get("builder", "unknown")
                            if builder not in builders:
                                builders[builder] = []
                            builders[builder].append(entry)
                        
                        print(f"   Уникальных builders: {len(builders)}")
                        if builders:
                            top_builder = max(builders.items(), key=lambda x: len(x[1]))
                            print(f"   Больше всего записей у: {top_builder[0]} ({len(top_builder[1])} дней)")
                else:
                    print(f"   ❌ Ошибка: HTTP {resp.status}")
        except Exception as e:
            print(f"   ❌ Исключение: {e}")
        
        # Тест 3: Различные time periods
        print("\n3️⃣ Тест: Различные time periods")
        for period in ["DAY", "WEEK", "MONTH"]:
            try:
                url = f"{base_url}/builders/leaderboard"
                params = {"timePeriod": period, "limit": 1}
                
                async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data:
                            volume = data[0].get("volume", 0)
                            print(f"   ✅ {period:5s}: Топ builder - {data[0].get('builder', 'N/A')} "
                                  f"(${volume:,})")
                    else:
                        print(f"   ❌ {period:5s}: HTTP {resp.status}")
            except Exception as e:
                print(f"   ❌ {period:5s}: {e}")
        
        print("\n" + "=" * 60)
        print("✅ Тестирование завершено!")
        print("=" * 60)


if __name__ == "__main__":
    asyncio.run(test_api())
