#!/usr/bin/env python3
"""
Улучшенная Four.Meme интеграция
"""
import asyncio
import aiohttp
import sys
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional

sys.path.append('.')

from main import BITQUERY_API_KEY, logger

async def fetch_fourmeme_tokens_improved(session: aiohttp.ClientSession) -> List[Dict]:
    """
    Улучшенная функция получения токенов с Four.Meme
    """
    if not BITQUERY_API_KEY:
        logger.debug("Bitquery API key not configured")
        return []

    try:
        # Динамическое время - последние 2 часа
        since_time = (datetime.now(timezone.utc) - timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%SZ")
        
        # Улучшенный GraphQL запрос для Bitquery
        query = """
        query {
          EVM(dataset: combined, network: bsc) {
            DEXTradeByTokens(
              orderBy: {descendingByField: "Block_Time"}
              limit: {count: 100}
              where: {
                Trade: {
                  Dex: {ProtocolName: {is: "fourmeme_v1"}}
                }
                Block: {
                  Time: {
                    since: "%s"
                  }
                }
              }
            ) {
              Trade {
                Currency {
                  Name
                  Symbol
                  SmartContract
                }
                Dex {
                  ProtocolName
                }
                Block {
                  Time
                }
                Price {
                  Amount
                }
                Transaction {
                  Hash
                }
              }
              volumeUsd: sum(of: Trade_Side_AmountInUSD)
              count: count
            }
          }
        }
        """ % since_time

        headers = {
            "Authorization": f"Bearer {BITQUERY_API_KEY}",
            "Content-Type": "application/json"
        }

        async with session.post(
            "https://graphql.bitquery.io",
            json={"query": query},
            headers=headers,
            timeout=30
        ) as response:
            if response.status != 200:
                logger.error(f"Bitquery API error: {response.status}")
                return []

            data = await response.json()
            
            if "errors" in data:
                logger.error(f"Bitquery GraphQL errors: {data['errors']}")
                return []

            trades = data.get("data", {}).get("EVM", {}).get("DEXTradeByTokens", [])
            logger.info(f"Four.Meme: fetched {len(trades)} tokens")
            
            return trades

    except Exception as e:
        logger.error(f"Error fetching Four.Meme tokens: {e}")
        return []

def parse_fourmeme_token_improved(trade: Dict) -> Optional[Dict]:
    """
    Улучшенный парсер токенов из Four.Meme
    """
    try:
        currency = trade["Trade"]["Currency"]
        block_time = trade["Trade"]["Block"]["Time"]
        
        # Время создания токена
        created_at = datetime.fromisoformat(block_time.replace("Z", "+00:00"))
        age_hours = (datetime.now(timezone.utc) - created_at).total_seconds() / 3600
        
        # Объем торгов
        volume_usd = float(trade.get("volumeUsd", 0))
        trade_count = int(trade.get("count", 0))
        
        # Адрес токена
        token_address = currency["SmartContract"].lower()
        if not token_address:
            return None
        
        # Исключаем WBNB/USDT
        if token_address in ["0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c", "0x55d398326f99059ff775485246999027b3197955"]:
            return None
        
        # Рассчитываем примерный 5-минутный объем
        # Если токен торгуется активно, предполагаем высокий объем
        volume_5m = volume_usd
        if trade_count > 10:  # Если много сделок, увеличиваем объем
            volume_5m = volume_usd * 1.5
        
        return {
            "token_address": token_address,
            "token_symbol": currency["Symbol"],
            "token_name": currency["Name"],
            "volume_5m": volume_5m,
            "volume_total": volume_usd,
            "trade_count": trade_count,
            "age_hours": age_hours,
            "is_new_token": age_hours < 2.0,  # Новые токены < 2 часов
            "source": "fourmeme",
            "first_trade": None,
            "last_trade": None,
            "price": trade["Trade"].get("Price", {}).get("Amount"),
            "tx_hash": trade["Trade"].get("Transaction", {}).get("Hash")
        }

    except Exception as e:
        logger.debug(f"Error parsing Four.Meme token: {e}")
        return None

async def test_fourmeme_improved():
    """Тестируем улучшенную Four.Meme интеграцию"""
    print("🧪 Тестируем улучшенную Four.Meme интеграцию...")
    
    async with aiohttp.ClientSession() as session:
        tokens = await fetch_fourmeme_tokens_improved(session)
        
        print(f"📊 Получено токенов: {len(tokens)}")
        
        parsed_tokens = []
        for token in tokens:
            parsed = parse_fourmeme_token_improved(token)
            if parsed:
                parsed_tokens.append(parsed)
        
        print(f"✅ Успешно распарсено: {len(parsed_tokens)}")
        
        # Показываем топ-5 токенов по объему
        if parsed_tokens:
            sorted_tokens = sorted(parsed_tokens, key=lambda t: t["volume_5m"], reverse=True)[:5]
            print("\n🏆 Топ-5 токенов по объему:")
            for i, token in enumerate(sorted_tokens, 1):
                print(f"{i}. {token['token_symbol']} ({token['token_name']})")
                print(f"   Адрес: {token['token_address']}")
                print(f"   Объем: ${token['volume_5m']:,.0f}")
                print(f"   Возраст: {token['age_hours']:.1f} часов")
                print(f"   Сделок: {token['trade_count']}")
                print(f"   Новый: {'✅' if token['is_new_token'] else '❌'}")
                print()

if __name__ == "__main__":
    asyncio.run(test_fourmeme_improved())
